package tea.tess.server;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import tea.tess.server.exceptions.UnknownCommandException;
import tea.tess.server.exceptions.WrongCommandFormatException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by arseniy on 12.10.15.
 */
public class Controller {
    private static String authorizeCommand, registerCommand;
    private static String wrongParamsCountExceptionMessage;
    protected static Path rootDirectory = Paths.get("/home/arseniy/root_sagor/");
    protected static Path currentDirectory = Paths.get(rootDirectory.toString());

    Controller() {

    }

    Controller(Socket clientSocket) {

    }

    Controller(String authorizeCommand, String registerCommand, String wrongParamsCountExceptionMessage) {
        this.authorizeCommand = authorizeCommand;
        this.registerCommand = registerCommand;
        this.wrongParamsCountExceptionMessage = wrongParamsCountExceptionMessage;
    }

    public static void recognize (String message) throws UnknownCommandException, IOException {
        int to = message.indexOf(" ");
        String command, params = "";
        if (to == -1)
            to = message.length();
        else
            params = message.substring(to + 1);
        command = message.substring(0, to);

        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[] {"config.xml"});
        Controller controller = (Controller) applicationContext.getBean("controller");
        try {
            if (command.equals(controller.getRegisterCommand()))
                AccountController.register(params);
            else if (command.equals(controller.getAuthorizeCommand()))
                AccountController.authorize(params);
            else
                FileSystemController.recognize(message);
        } catch (WrongCommandFormatException e) {
            Main.setResponce(e.getMessage());
        } catch (UnknownCommandException e) {
            Main.setResponce(e.getMessage());
        } catch (FileNotFoundException e) {
            Main.setResponce(e.getMessage());
        } catch (NullPointerException e) {
            Main.setResponce(e.getMessage());
        }
    }

    protected static void wrongParamsCount() throws WrongCommandFormatException {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[] {"config.xml"});
        Controller controller = (Controller) applicationContext.getBean("controller");
        throw new WrongCommandFormatException(controller.getWrongParamsCountExceptionMessage());
    }

    public static String getAuthorizeCommand() {
        return authorizeCommand;
    }

    public static void setAuthorizeCommand(String authorizeCommand) {
        Controller.authorizeCommand = authorizeCommand;
    }

    public static String getRegisterCommand() {
        return registerCommand;
    }

    public static void setRegisterCommand(String registerCommand) {
        Controller.registerCommand = registerCommand;
    }

    public static String getWrongParamsCountExceptionMessage() {
        return wrongParamsCountExceptionMessage;
    }

    public static void setWrongParamsCountExceptionMessage(String wrongParamsCountExceptionMessage) {
        Controller.wrongParamsCountExceptionMessage = wrongParamsCountExceptionMessage;
    }
}
