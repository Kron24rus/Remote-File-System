package tea.tess.server;

import tea.tess.server.exceptions.WrongCommandFormatException;

/**
 * Created by arseniy on 12.10.15.
 */
public class AccountController extends Controller {
    public static void register(String params) throws WrongCommandFormatException {
        String[] data = params.split(" "); // data[0] == login, data[1] == password
        if (data.length != 2) {
            wrongParamsCount();
            return;
        }
        // Register

    }

    public static void authorize(String params) throws WrongCommandFormatException {
        String[] data = params.split(" "); // data[0] == login, data[1] == password
        if (data.length != 2) {
            wrongParamsCount();
            return;
        }
        // Authorize

    }
}
