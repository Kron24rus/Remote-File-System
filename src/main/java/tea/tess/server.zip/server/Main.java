package tea.tess.server;

import tea.tess.server.exceptions.UnknownCommandException;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by arseniy on 12.10.15.
 */
public class Main {
    public static final int PORT = 12573;

    private static String OS;
    private static ServerSocket serverSocket;
    private static String message;
    private static String responce = "";
    private static File file;

    public static void main(String[] args) {
        try {
            // Getting file
            serverSocket = new ServerSocket(PORT);
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (true) {
            try {
                Socket clientSocket = serverSocket.accept();
                BufferedReader socketReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                while (!socketReader.ready()) {}
                message = socketReader.readLine();

                System.out.println("He says: " + message);

                OS = recognizeOperatingSystem();
                Controller.recognize(message);
                /* // DOWNLOAD
                file = new File(filePath + fileName);
                BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(file));
                while (inputStream.available() > 0)
                    outputStream.write(inputStream.read());
                outputStream.close();
                inputStream.close();
                System.out.println("File readed");
                */

                PrintWriter printWriter = new PrintWriter(clientSocket.getOutputStream(), true);
                printWriter.println(responce);
                printWriter.close();
                /*
                // EXECUTING
                ProcessBuilder builder = new ProcessBuilder(
                        "cmd.exe", "/c", "java -classpath " + filePath + fileName + " " + mainClassName
                );
                System.out.println("java -classpath " + filePath + fileName + " " + mainClassName);
                builder.redirectErrorStream(true);
                try {
                    Process p = builder.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                System.out.println("File executed");
                */

            } catch (IOException exception) {
                exception.printStackTrace();
            } catch (UnknownCommandException e) {
                e.printStackTrace();
            } catch (SecurityException e) {
                e.printStackTrace();
            } finally {
                if (file != null)
                    if (file.exists())
                        file.delete();
            }
        }
    }

    private static String recognizeOperatingSystem() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.indexOf( "win" ) >= 0)
            return "Windows";
        else if (os.indexOf( "mac" ) >= 0)
            return "Mac";
        else if (os.indexOf( "nix") >=0 || os.indexOf( "nux") >=0)
            return "Unix";
        else
            return "unknown";
    }

    public static void setResponce(String message) {
        responce = message;
    }

    public static String getOS() {
        return OS;
    }
}
