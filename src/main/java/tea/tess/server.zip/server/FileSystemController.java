package tea.tess.server;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import tea.tess.server.exceptions.UnknownCommandException;
import tea.tess.server.exceptions.UnsupportedFileTypeException;
import tea.tess.server.exceptions.WrongCommandFormatException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

/**
 * Created by arseniy on 12.10.15.
 */
public class FileSystemController extends Controller {
    private static String changeDirCommand, createDirCommand, displayDirCommand, createFileCommand, showFileCommand,
            copyCommand, removeCommand, moveCommand, uploadFileCommand, downloadFileCommand;

    public FileSystemController(String changeDirCommand, String createDirCommand, String displayDirCommand, String createFileCommand, String showFileCommand,
                                String copyCommand, String removeCommand, String moveCommand, String uploadFileCommand, String downloadFileCommand) {
        this.changeDirCommand = changeDirCommand;
        this.createDirCommand = createDirCommand;
        this.displayDirCommand = displayDirCommand;
        this.createFileCommand = createFileCommand;
        this.showFileCommand = showFileCommand;
        this.copyCommand = copyCommand;
        this.removeCommand = removeCommand;
        this.moveCommand = moveCommand;
        this.uploadFileCommand = uploadFileCommand;
        this.downloadFileCommand = downloadFileCommand;
    }

    public static void recognize(String message) throws UnknownCommandException, IOException {
        int to = message.indexOf(" ");
        String command, params = "";
        if (to == -1)
            to = message.length();
        else
            params = message.substring(to + 1);
        command = message.substring(0, to);

        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[] {"config.xml"});
        FileSystemController controller = (FileSystemController) applicationContext.getBean("FScontroller");
        try {
            if (command.equals(controller.getChangeDirCommand()))
                cd(params);
            else if (command.equals(controller.getCreateDirCommand()))
                mkdir(params);
            else if (command.equals(controller.getDisplayDirCommand()))
                ls(params);
            else if (command.equals(controller.getCreateFileCommand()))
                touch(params);
            else if (command.equals(controller.getShowFileCommand()))
                cat(params);
            else if (command.equals(controller.getCopyCommand())) {
                String[] p = params.split(" ");
                if (p.length != 2)
                    throw new WrongCommandFormatException("Unknown count of parameters: " + p.length);
                cp(p[0], p[1]);
            }
            else if (command.equals(controller.getRemoveCommand()))
                rm(params);
            else if (command.equals(controller.getMoveCommand()))
                mv(params);
            else if (command.equals(controller.getUploadFileCommand()))
                push(params);
            else if (command.equals(controller.getDownloadFileCommand()))
                get(params);
            else
                throw new UnknownCommandException("No such command found: " + command);
        } catch (WrongCommandFormatException e) {
            Main.setResponce(e.getMessage());
        } catch (SecurityException e) {
            Main.setResponce(e.getMessage());
        } catch (UnsupportedFileTypeException e) {
            Main.setResponce(e.getMessage());
        } catch (IOException e) {
            Main.setResponce(e.getMessage());
        }
    }

    private static boolean isOutOfRoot(Path file) {
        if (!file.normalize().toString().startsWith(rootDirectory.toString()))
            return true;
        else
            return false;
    }

    private static String getUsersPath (Path path) throws SecurityException {
        if (!isOutOfRoot(path)) {
            return path.toString().substring(rootDirectory.getParent().toString().length());
        } else
            throw new SecurityException("Out of root!");
    }

    /**
     * Function cd - changes current directory.
     * Usage:
     * cd path
     */

    private static void cd(String path) throws WrongCommandFormatException, IOException {
        Path file = Paths.get(currentDirectory + File.separator + path).normalize();
        if (isOutOfRoot(file))
            throw new SecurityException("Out of root!");
        if (Files.exists(file)) {
            currentDirectory = file;
            String usersPath = getUsersPath(currentDirectory);
            if (usersPath != null)
                Main.setResponce(usersPath);
            else
                throw new NullPointerException();
        }
        else
            throw new FileNotFoundException("No such directory: " + file);
    }

    /**
     * Function mkdir - creates a new directory.
     * Usage:
     * mkdir path
     */

    private static void mkdir(String path) throws IOException {
        Path file = Paths.get(currentDirectory + File.separator + path).normalize();
        if (isOutOfRoot(file))
            throw new SecurityException("Out of root!");
        if (!Files.exists(file)) {
            Files.createDirectory(file);
            String usersPath = getUsersPath(file);
            if (usersPath != null)
                Main.setResponce("Directory " + usersPath + " created successfully");
            else
                throw new NullPointerException();
        }
        else
            throw new FileAlreadyExistsException("Directory already exists: " + path);
    }

    /**
     * Function ls - displays the contents of a directory.
     * Usage:
     * ls [path]
     */

    private static void ls(String path) throws IOException {
        Path file = Paths.get(currentDirectory + File.separator + path).normalize();
        if (isOutOfRoot(file))
            throw new SecurityException("Out of root!");
        if (Files.exists(file))
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(file)) {
                StringBuilder builder = new StringBuilder();
                for (Path p : stream) {
                    builder.append(p.getFileName() + "\n");
                }
                Main.setResponce(builder.toString());
            } catch (IOException e) {
                Main.setResponce("Error while reading directory. Try again later.");
            }
        else
            throw new FileNotFoundException("No such directory: " + file);
    }

    /**
     * Function touch - creates a new file.
     * Usage:
     * touch path
     */

    private static void touch(String path) throws IOException {
        Path file = Paths.get(currentDirectory + File.separator + path).normalize();
        if (isOutOfRoot(file))
            throw new SecurityException("Out of root!");
        if (!Files.exists(file)) {
            Files.createFile(file);
            String usersPath = getUsersPath(file);
            if (usersPath != null)
                Main.setResponce("File " + usersPath + " created successfully");
            else
                throw new NullPointerException();
        }
        else
            throw new FileAlreadyExistsException("File already exists: " + path);
    }

    /**
     * Function cat - displays content of text file or image to user.
     * Usage:
     * cat path
     */

    private static void cat(String path) throws IOException, UnsupportedFileTypeException {
        Path file = Paths.get(currentDirectory + File.separator + path).normalize();
        if (isOutOfRoot(file))
            throw new SecurityException("Out of root!");
        if (Files.exists(file)) {
            if (file.getFileName().toString().endsWith(".txt")) {
                RandomAccessFile aFile = new RandomAccessFile(file.toString(), "r");
                FileChannel inChannel = aFile.getChannel();
                MappedByteBuffer buffer = inChannel.map(FileChannel.MapMode.READ_ONLY, 0, inChannel.size());
                buffer.load();
                StringBuilder result = new StringBuilder();
                for (int i = 0; i < buffer.limit(); i++) {
                    result.append((char) buffer.get());
                }
                buffer.clear();
                inChannel.close();
                aFile.close();
                Main.setResponce(result.toString());
            } else
                throw new UnsupportedFileTypeException("Unsupported file extension: " + file.getFileName().toString());
        }
        else
            throw new FileNotFoundException("No such directory: " + file);
    }

    /**
     * Function cp - copy file or directory "path1" to "path2".
     * Usage:
     * cp path1 path2
     */

    private static void cp(String path1, final String path2) throws IOException {
        final Path file1 = Paths.get(currentDirectory + File.separator + path1).normalize();
        final Path file2 = Paths.get(currentDirectory + File.separator + path1).normalize();
        if (isOutOfRoot(file1) || isOutOfRoot(file2))
            throw new SecurityException("Out of root!");
        if (!Files.exists(file1)) {
            throw new NoSuchFileException("No such file exists: " + path1);
        } else if (Files.exists(file2)) {
            throw new FileAlreadyExistsException("File already exists: " + path2);
        } else {
            if (!Files.isDirectory(file1)) {
                Files.copy(file1, file2);
            } else
                try {
                    Files.walkFileTree(file1, new SimpleFileVisitor<Path>() {

                        public FileVisitResult visitFile(Path path, BasicFileAttributes attribs) throws IOException {
                            String subDir = path.toString().substring(file1.toString().length());
                            Files.copy(path, Paths.get(path2 + File.separator + subDir));
                            return FileVisitResult.CONTINUE;
                        }
                    });
                }
                catch(IOException e) {
                    e.printStackTrace();
                }

            Main.setResponce("Copying completed successfully");
        }
    }

    /**
     * Function rm - remove file.
     * Usage:
     * rm path
     */

    private static void rm(String path) throws IOException { //InputStream file, String name) {
        final Path file = Paths.get(currentDirectory + File.separator + path).normalize();
        if (isOutOfRoot(file))
            throw new SecurityException("Out of root!");
        if (!Files.exists(file)) {
            throw new NoSuchFileException("No such file exists: " + file);
        } else {
            if (!Files.isDirectory(file)) {
                Files.delete(file);
            } else
                try {
                    Files.walkFileTree(file, new SimpleFileVisitor<Path>() {

                        public FileVisitResult visitFile(Path path, BasicFileAttributes attribs) throws IOException {
                            Files.delete(path);
                            return FileVisitResult.CONTINUE;
                        }
                    });
                }
                catch(IOException e) {
                    e.printStackTrace();
                }

            Main.setResponce("Deleting completed successfully");
        }
    }

    /**
     * Function push - uploads a file to server.
     * Usage:
     * push path
     */

    private static void mv(String params) { //InputStream file, String name) {

    }

    /**
     * Function push - uploads a file to server.
     * Usage:
     * push path
     */

    private static void push(String params) { //InputStream file, String name) {

    }

    /**
     * Function get - downloads a file from server.
     * Usage:
     * get path
     */

    private static void get(String path) {

    }

    public static String getChangeDirCommand() {
        return changeDirCommand;
    }

    public static void setChangeDirCommand(String changeDirCommand) {
        FileSystemController.changeDirCommand = changeDirCommand;
    }

    public static String getCreateDirCommand() {
        return createDirCommand;
    }

    public static void setCreateDirCommand(String createDirCommand) {
        FileSystemController.createDirCommand = createDirCommand;
    }

    public static String getDisplayDirCommand() {
        return displayDirCommand;
    }

    public static void setDisplayDirCommand(String displayDirCommand) {
        FileSystemController.displayDirCommand = displayDirCommand;
    }

    public static String getCreateFileCommand() {
        return createFileCommand;
    }

    public static void setCreateFileCommand(String createFileCommand) {
        FileSystemController.createFileCommand = createFileCommand;
    }

    public static String getShowFileCommand() {
        return showFileCommand;
    }

    public static void setShowFileCommand(String showFileCommand) {
        FileSystemController.showFileCommand = showFileCommand;
    }

    public static String getUploadFileCommand() {
        return uploadFileCommand;
    }

    public static void setUploadFileCommand(String uploadFileCommand) {
        FileSystemController.uploadFileCommand = uploadFileCommand;
    }

    public static String getDownloadFileCommand() {
        return downloadFileCommand;
    }

    public static void setDownloadFileCommand(String downloadFileCommand) {
        FileSystemController.downloadFileCommand = downloadFileCommand;
    }

    public static String getCopyCommand() {
        return copyCommand;
    }

    public static void setCopyCommand(String copyCommand) {
        FileSystemController.copyCommand = copyCommand;
    }

    public static String getRemoveCommand() {
        return removeCommand;
    }

    public static void setRemoveCommand(String removeCommand) {
        FileSystemController.removeCommand = removeCommand;
    }

    public static String getMoveCommand() {
        return moveCommand;
    }

    public static void setMoveCommand(String moveCommand) {
        FileSystemController.moveCommand = moveCommand;
    }
}
