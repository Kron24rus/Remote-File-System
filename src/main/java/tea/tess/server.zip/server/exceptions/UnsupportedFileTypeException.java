package tea.tess.server.exceptions;

/**
 * Created by arseniy on 14.10.15.
 */
public class UnsupportedFileTypeException extends Exception {
    public UnsupportedFileTypeException(String message) {
        super(message);
    }
}
